var app = angular.module('myApp', []);

app.controller('myController', ['$scope', function($scope) {
    $scope.msg = "Hello from ng jasmin karma app";
}]);

