describe ('Basic karma testing', function(){
    console.log('inside describe');
    it('should add two numbers correctly', function(){
        console.log('inside it');
        expect(4+5).toEqual(9);
    });
});

describe('Basic karma angular testing', function() {

    beforeEach(module('myApp'));

    var myController;
    var scope;

    beforeEach(inject(function ($rootScope, $controller) {
        scope = $rootScope.$new();
        myController = $controller('myController', {
            $scope: scope
        });
    }));
    it('says Hello from ng jasmin karma app', function () {
        expect(scope.msg).toEqual('Hello from ng jasmin karma app');
    });

});