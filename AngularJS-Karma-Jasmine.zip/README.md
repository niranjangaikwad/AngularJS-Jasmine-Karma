This is basic setup to test angular with jasmin by running it using karma

Ref: AngularJS controller scope testing
https://blog.logentries.com/2015/01/unit-testing-with-karma-and-jasmine-for-angularjs/

Ref: Testing AngularJS service http://www.dotnetcurry.com/angularjs/1255/unit-testing-angularjs-using-jasmine-karma

Note: We had to add missing dependancies and configurations which were not given in above link

Steps followed
1. Open cmd and run npm install
2. Run using http://localhost:3002
3. Open another cmd and test using npm test (which calls command karma start karma.conf.js)
4. It should run two test cases viz. one for addition and another for testing angular controller output